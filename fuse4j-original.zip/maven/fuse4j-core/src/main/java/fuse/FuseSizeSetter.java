package fuse;

/**
 * User: peter
 * Date: Nov 16, 2005
 * Time: 9:30:54 AM
 */
public interface FuseSizeSetter
{
   public void setSize(int size);
}
