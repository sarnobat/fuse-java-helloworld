package fuse;

/**
 * User: peter
 * Date: Nov 16, 2005
 * Time: 9:28:10 AM
 */
public interface XattrLister
{
   public void add(String xattrName);
}
