package fuse;

public interface LifecycleSupport {

    public int init();
    public int destroy();

}
