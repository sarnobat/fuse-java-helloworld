#ifndef _NATIVE_IMPL_H_
#define _NATIVE_IMPL_H_

#include "javafs.h"

int RegisterNativeMethods(JNIEnv *env);

#endif
