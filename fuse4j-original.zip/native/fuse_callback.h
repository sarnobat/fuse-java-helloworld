#ifndef _FUSE_CALLBACK_H_
#define _FUSE_CALLBACK_H_

#include "javafs.h"

extern struct fuse_operations javafs_oper;

#endif
